"use client";

import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { TextAnimate } from '@/components/ui/text-animate';
import { Ripple } from '@/components/ui/ripple';
import Link from 'next/link';

const GitHubIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
  </svg>
);

interface CtaSectionProps {
  className?: string;
}

export const CtaSection: React.FC<CtaSectionProps> = ({ className = '' }) => {
  return (
    <div className={`CtaSection py-16 md:py-24 lg:py-32 overflow-hidden ${className}`} style={{ position: 'relative' }} data-cta-section>
      {/* Dot Pattern Background - Square Container */}
      <div className="absolute inset-0 flex items-center justify-center z-0">
      </div>
      
      {/* Ripple Effect Background */}
      <div className="absolute inset-0 z-0">
        <Ripple 
          mainCircleSize={200}
          mainCircleOpacity={0.3}
          numCircles={6}
          className="opacity-100"
        />
      </div>
      
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        {/* Big Headline */}
        <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-medium text-center tracking-tight mb-6 sm:mb-8">
          <TextAnimate
            by="word"
            animation="blurInUp"
            delay={0.1}
            duration={0.8}
            className="inline text-primary"
          >
            Ready to Automate Your Monitoring?
          </TextAnimate>
        </h1>
        
        {/* Subtitle */}
        <h2 className="text-xl sm:text-2xl md:text-3xl font-medium text-center text-muted-foreground mb-8 sm:mb-12 max-w-3xl mx-auto px-4 leading-relaxed">
          <TextAnimate
            by="word"
            animation="fadeIn"
            delay={0.5}
            duration={0.6}
            className="inline"
          >
            Stop watching screens.
            Start receiving intelligent reports.
          </TextAnimate>
        </h2>
        
        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center items-center px-4">
          <Button
            size="lg"
            className="group px-8 py-4 text-lg font-medium bg-primary hover:bg-primary/90 shadow-lg"
            asChild
          >
            <Link href="/dashboard">
            Get Started
            </Link>
          </Button>
          
          <Button
            variant="outline"
            size="lg"
            className="group px-6 py-4 text-lg font-medium bg-neutral-900 border-neutral-800 text-white hover:bg-neutral-800"
            asChild
          >
            <a href="/dashboard" target="_blank" rel="noopener noreferrer">
            Request Demo
              {/* <GitHubIcon /> */}
            </a>
          </Button>
        </div>
      </div>
    </div>
  );
};
